package com.example.ch407a_poem_learner

import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp

@Composable
fun PoemLearner(poem: Poem) {
    var showFullPoem by remember { mutableStateOf(false) }
    val quatrains = remember { poem.content.split("\n\n") }
    var currentQuatrainIndex by remember { mutableStateOf(0) }
    
    LazyColumn(
        modifier = Modifier
            .fillMaxSize()
            .padding(16.dp),
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        item {
            Text(
                text = poem.title,
                fontSize = 24.sp,
                fontWeight = FontWeight.Bold
            )
            Spacer(modifier = Modifier.height(8.dp))
            Text(
                text = "Автор: ${poem.author}",
                fontSize = 18.sp,
                color = MaterialTheme.colorScheme.secondary
            )
            Spacer(modifier = Modifier.height(16.dp))
            Text(
                text = if (showFullPoem) poem.content else quatrains[currentQuatrainIndex],
                fontSize = 16.sp
            )
            Spacer(modifier = Modifier.height(16.dp))
            Button(
                onClick = { showFullPoem = !showFullPoem }
            ) {
                Text(if (showFullPoem) "Показать по четверостишиям" else "Показать полностью")
            }
            Spacer(modifier = Modifier.height(32.dp))
            LearningControls(
                onPrevious = {
                    if (currentQuatrainIndex > 0) currentQuatrainIndex--
                },
                onNext = {
                    if (currentQuatrainIndex < quatrains.size - 1) currentQuatrainIndex++
                },
                showFullPoem = showFullPoem
            )
        }
    }
}

@Composable
fun LearningControls(
    onPrevious: () -> Unit,
    onNext: () -> Unit,
    showFullPoem: Boolean
) {
    Row(
        modifier = Modifier.fillMaxWidth(),
        horizontalArrangement = Arrangement.SpaceEvenly
    ) {
        Button(
            onClick = onPrevious,
            enabled = !showFullPoem
        ) {
            Text("Предыдущее четверостишие")
        }
        Button(
            onClick = onNext,
            enabled = !showFullPoem
        ) {
            Text("Следующее четверостишие")
        }
    }
    Spacer(modifier = Modifier.height(16.dp))
    Button(
        onClick = { /* TODO: Check knowledge */ },
        modifier = Modifier.fillMaxWidth()
    ) {
        Text("Проверить знание")
    }
}