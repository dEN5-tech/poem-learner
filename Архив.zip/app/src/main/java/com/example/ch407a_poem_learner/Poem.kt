package com.example.ch407a_poem_learner

data class Poem(val title: String, val author: String, val content: String)