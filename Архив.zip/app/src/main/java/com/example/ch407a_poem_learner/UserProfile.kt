package com.example.ch407a_poem_learner

import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp

@Composable
fun UserProfile() {
    Column(
        modifier = Modifier
            .fillMaxSize()
            .padding(16.dp),
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        Icon(
            painter = painterResource(id = R.drawable.ic_account_circle),
            contentDescription = "Профиль",
            modifier = Modifier.size(100.dp)
        )
        Spacer(modifier = Modifier.height(16.dp))
        Text(
            "Иван Иванов",
            fontSize = 24.sp,
            fontWeight = FontWeight.Bold
        )
        Spacer(modifier = Modifier.height(8.dp))
        Text("Уровень: Средний", fontSize = 18.sp)
        Spacer(modifier = Modifier.height(16.dp))
        LinearProgressIndicator(
            progress = 0.6f,
            modifier = Modifier.fillMaxWidth()
        )
        Spacer(modifier = Modifier.height(8.dp))
        Text("Прогресс: 60%", fontSize = 16.sp)
        Spacer(modifier = Modifier.height(16.dp))
        UserStatsList()
    }
}

@Composable
fun UserStatsList() {
    val stats = listOf(
        "Изучено стихов" to "5",
        "Любимый автор" to "Александр Пушкин",
        "Дней подряд" to "7",
        "Общее время изучения" to "3ч 45мин"
    )

    LazyColumn {
        items(stats) { (label, value) ->
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(vertical = 8.dp),
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                Text(text = label, fontSize = 16.sp)
                Text(text = value, fontSize = 16.sp, fontWeight = FontWeight.Bold)
            }
        }
    }
}