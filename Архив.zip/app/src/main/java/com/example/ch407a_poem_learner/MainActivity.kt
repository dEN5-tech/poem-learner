package com.example.ch407a_poem_learner

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import androidx.navigation.compose.NavHost
import androidx.navigation.compose.composable
import androidx.navigation.compose.rememberNavController
import java.net.URLEncoder
import java.nio.charset.StandardCharsets

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent {
            MaterialTheme {
                Surface(
                    modifier = Modifier.fillMaxSize(),
                    color = MaterialTheme.colorScheme.background
                ) {
                    PoemApp()
                }
            }
        }
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun PoemApp() {
    val navController = rememberNavController()
    var poems by remember { mutableStateOf(listOf<Poem>()) }

    NavHost(navController = navController, startDestination = "poemList") {
        composable("poemList") {
            PoemListScreen(
                poems = poems,
                onPoemSelected = { poem ->
                    val encodedTitle = URLEncoder.encode(poem.title, StandardCharsets.UTF_8.toString())
                    val encodedAuthor = URLEncoder.encode(poem.author, StandardCharsets.UTF_8.toString())
                    navController.navigate("poemLearner/$encodedTitle/$encodedAuthor")
                },
                onAddPoemClick = {
                    navController.navigate("addPoem")
                }
            )
        }
        composable("poemLearner/{title}/{author}") { backStackEntry ->
            val title = backStackEntry.arguments?.getString("title")?.let { java.net.URLDecoder.decode(it, StandardCharsets.UTF_8.toString()) }
            val author = backStackEntry.arguments?.getString("author")?.let { java.net.URLDecoder.decode(it, StandardCharsets.UTF_8.toString()) }
            val poem = poems.find { it.title == title && it.author == author }
            poem?.let {
                PoemLearner(poem = it)
            }
        }
        composable("addPoem") {
            AddPoemScreen(
                onPoemAdded = { newPoem ->
                    poems = poems + newPoem
                    navController.navigate("poemList")
                }
            )
        }
    }
}

@Composable
fun PoemListScreen(
    poems: List<Poem>,
    onPoemSelected: (Poem) -> Unit,
    onAddPoemClick: () -> Unit
) {
    var searchQuery by remember { mutableStateOf("") }

    Column(modifier = Modifier.fillMaxSize()) {
        OutlinedTextField(
            value = searchQuery,
            onValueChange = { searchQuery = it },
            label = { Text("Поиск стихотворений") },
            modifier = Modifier
                .fillMaxWidth()
                .padding(16.dp)
        )

        LazyColumn(modifier = Modifier.weight(1f)) {
            val filteredPoems = poems.filter { poem ->
                poem.title.contains(searchQuery, ignoreCase = true) ||
                poem.author.contains(searchQuery, ignoreCase = true) ||
                poem.content.contains(searchQuery, ignoreCase = true)
            }
            items(filteredPoems) { poem ->
                PoemListItem(poem) {
                    onPoemSelected(poem)
                }
            }
        }

        Button(
            onClick = onAddPoemClick,
            modifier = Modifier
                .fillMaxWidth()
                .padding(16.dp)
        ) {
            Text("Добавить стихотворение")
        }
    }
}

// Функция PoemListItem удалена отсюда