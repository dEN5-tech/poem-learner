package com.example.ch407a_poem_learner

import androidx.compose.foundation.layout.*
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Add
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.tooling.preview.Preview
import androidx.navigation.compose.NavHost
import androidx.navigation.compose.composable
import androidx.navigation.compose.rememberNavController
import androidx.navigation.NavType
import androidx.navigation.navArgument
import com.example.ch407a_poem_learner.ui.theme.ВоробьёвTheme

@OptIn(ExperimentalMaterial3Api::class)
@Composable
@Preview
fun PoemLearnerApp() {
    var isDarkMode by remember { mutableStateOf(false) }
    var searchQuery by remember { mutableStateOf("") }
    val navController = rememberNavController()

    val poemList = remember { mutableStateListOf(
        Poem("Стихотворение 1", "Автор 1", "Компьютеры — каких их только нет,\n" +
                "И стало модным слово «Интернет»,\n" +
                "Век программистов — 21-й век,\n" +
                "Достиг вершин науки человек!\n" +
                "\n" +
                "Программисты — народ удивительный,\n" +
                "Современный и умный народ,\n" +
                "У них всё и всегда относительно\n" +
                "Виртуально стремится вперёд.\n" +
                "\n" +
                "Когда-то сам великий Гейтс,\n" +
                "Сверходарённый, он же — Билл\n" +
                "Был как цветочек эдельвейс,\n" +
                "Систему «Виндовс» сотворил.\n" +
                "\n" +
                "Народ чудесный — программисты,\n" +
                "Суперчуствительный народ:\n" +
                "Напишет всё на сайте чистом,\n" +
                "Задаст программу и — вперёд!\n" +
                "\n" +
                "Программиста хлебом не корми —\n" +
                "Дай за монитором посидеть,\n" +
                "Если же компьютер отменить —\n" +
                "Долго будет плакать и реветь.\n" +
                "\n" +
                "Каждый программист — почти профессор,\n" +
                "Музыкант своей клавиатуры,\n" +
                "Чаще будет там, где есть процессор,\n" +
                "К виртуальной приобщён культуре.\n" +
                "\n" +
                "Он не может усидеть на месте\n" +
                "И всегда находится на сайтах,\n" +
                "Голова забита, как винчестер,\n" +
                "Мысли — в байтах, кило-, терабайтах.\n" +
                "\n" +
                "День стучит под пальчиками клава,\n" +
                "Программист идею подаёт,\n" +
                "С++ и РНР , и Ява —\n" +
                "С ними он программы создаёт.\n" +
                "\n" +
                "Он не мыслит жизни без модема,\n" +
                "Только с ним выходит в интернет,\n" +
                "В чате разрешаются проблемы,\n" +
                "Можно пообщаться, спору нет.\n" +
                "\n" +
                "Он жену находит в интернете,\n" +
                "Женятся, коль близко подойдут,\n" +
                "И когда у них родятся дети —\n" +
                "Линуксом ребёнка назовут.\n" +
                "\n" +
                "Программиста ценят как начальника,\n" +
                "Всем он безотказно помогает,\n" +
                "Пользователь просит или чайники —\n" +
                "Чётко, терпеливо объясняет.\n" +
                "\n" +
                "Если возникают вдруг вопросы,\n" +
                "Надо что-то новое узнать —\n" +
                "Программист научит очень просто\n" +
                "В Гугле или Яндексе скачать.\n" +
                "\n" +
                "Он компьютер ваш спасёт от вируса,\n" +
                "Плату материнскую заменит,\n" +
                "Захотите — поменяет виндовс,\n" +
                "Кто же программиста вам заменит?!\n" +
                "\n" +
                "Программист — весёлый, беззаботный,\n" +
                "Ценит юмор и шутить умеет,\n" +
                "Быстро свою сделает работу,\n" +
                "Всё, всегда и всюду одолеет!"),
        Poem("Стихотворение 2", "Автор 2", "Краткое содержание 2"),
        Poem("Стихотворение 3", "Автор 3", "Краткое содержание 3")
    ) }

    ВоробьёвTheme(darkTheme = isDarkMode) {
        Scaffold(
            topBar = {
                TopAppBar(
                    title = { Text("Изучение Стихов") },
                    actions = {
                        IconButton(onClick = { isDarkMode = !isDarkMode }) {
                            Icon(
                                painter = painterResource(id = if (isDarkMode) R.drawable.ic_light_mode else R.drawable.ic_dark_mode),
                                contentDescription = "Переключить тёмный режим"
                            )
                        }
                        IconButton(onClick = { navController.navigate("addPoem") }) {
                            Icon(
                                imageVector = Icons.Default.Add,
                                contentDescription = "Добавить стихотворение"
                            )
                        }
                    }
                )
            },
            bottomBar = {
                NavigationBar {
                    NavigationBarItem(
                        icon = { Icon(painter = painterResource(id = R.drawable.ic_poem_list), contentDescription = "Список Стихов") },
                        label = { Text("Стихи") },
                        selected = navController.currentDestination?.route == "poemList",
                        onClick = { navController.navigate("poemList") }
                    )
                    NavigationBarItem(
                        icon = { Icon(painter = painterResource(id = R.drawable.ic_profile), contentDescription = "Профиль") },
                        label = { Text("Профиль") },
                        selected = navController.currentDestination?.route == "userProfile",
                        onClick = { navController.navigate("userProfile") }
                    )
                }
            }
        ) { innerPadding ->
            Column(modifier = Modifier.padding(innerPadding)) {
                SearchBar(
                    query = searchQuery,
                    onQueryChange = { searchQuery = it },
                    onSearch = { /* Implement search functionality */ },
                    active = false,
                    onActiveChange = {},
                    modifier = Modifier.fillMaxWidth()
                ) {
                    /* Search suggestions can be added here */
                }

                NavHost(navController = navController, startDestination = "poemList") {
                    composable("poemList") { 
                        PoemList(poemList) { poemIndex ->
                            navController.navigate("poemLearner/$poemIndex")
                        }
                    }
                    composable("userProfile") { UserProfile() }
                    composable(
                        "poemLearner/{poemIndex}",
                        arguments = listOf(navArgument("poemIndex") { type = NavType.IntType })
                    ) { backStackEntry ->
                        val poemIndex = backStackEntry.arguments?.getInt("poemIndex") ?: 0
                        PoemLearner(poemList[poemIndex])
                    }
                    composable("addPoem") {
                        AddPoemScreen(
                            onPoemAdded = { newPoem ->
                                poemList.add(newPoem)
                                navController.navigateUp()
                            }
                        )
                    }
                }
            }
        }
    }
}