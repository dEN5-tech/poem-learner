package com.example.ch407a_poem_learner

import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.itemsIndexed
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp

@Composable
fun PoemList(poems: List<Poem>, onPoemClick: (Int) -> Unit) {
    LazyColumn {
        itemsIndexed(poems) { index, poem ->
            PoemListItem(poem, onClick = { onPoemClick(index) })
        }
    }
}

@Composable
fun PoemListItem(poem: Poem, onClick: () -> Unit) {
    Card(
        modifier = Modifier
            .fillMaxWidth()
            .padding(8.dp)
            .clickable(onClick = onClick),
        elevation = CardDefaults.cardElevation(defaultElevation = 4.dp)
    ) {
        Column(modifier = Modifier.padding(16.dp)) {
            Text(text = poem.title, fontSize = 18.sp, fontWeight = FontWeight.Bold)
            Text(text = "Автор: ${poem.author}", fontSize = 14.sp, color = MaterialTheme.colorScheme.secondary)
            Text(text = poem.content, fontSize = 14.sp, maxLines = 2, overflow = androidx.compose.ui.text.style.TextOverflow.Ellipsis)
        }
    }
}